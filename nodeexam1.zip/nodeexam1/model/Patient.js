const Sequelize=require("sequelize");
const db1= require("../db.config");
var sequelize = new Sequelize(db1.DB,db1.USER,db1.PASSWORD,{
    host:db1.HOST,
    dialect:db1.dialect,
    pool:{
        min:db1.pool.min,
        max:db1.pool.max,
        acquire:db1.pool.acquire,
        idle:db1.pool.idle
    }
});

let PatientTable=sequelize.define('PatientTable',{
    id:{
       primaryKey:true,
       type:Sequelize.STRING
     },
     patient:Sequelize.STRING,
     vital_sign:Sequelize.STRING,
     value:Sequelize.STRING,
     note:Sequelize.STRING
   
},{
   timestamps:false,
   freezeTableName:true
});


// PatientTable.sync({force:true}).then(()=>{
//     console.log("Table created successfully")
// }).catch (err => {
//     console.error("Error"+err);
// });

const PatientData=
{
    patient: function(req,res){
        console.log(req.body);
   var id =  req.body.id;
   var patient =  req.body.patient;
   var vital_sign =  req.body.vital_sign;
   var value =  req.body.value;
   var note =  req.body.note;
   
   var UserObj=PatientTable.build({id:id,
    patient:patient,vital_sign:vital_sign,value:value,note:note});
   UserObj.save().then(()=>{
       console.log("Query Successfully Send");
       res.send("Query Successfully Send");
   }).catch((err)=>{
       console.log("Error Encountered"+err);
       res.send("Error Encountered");
     })  
   }
}

module.exports=PatientData;