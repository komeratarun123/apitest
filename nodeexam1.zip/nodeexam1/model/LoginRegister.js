const Sequelize=require("sequelize");
const db2= require("../db.config");

var sequelize= new Sequelize(db2.DB,db2.USER,db2.PASSWORD,{
    host:db2.HOST,
    dialect:db2.dialect,
    pool:{
        max:db2.pool.max,
        min:db2.pool.min,
        acquire:db2.pool.acquire,
        idle:db2.pool.idle
    }
 });
 let LoginRegisterTable= sequelize.define('LoginRegisterTable',{  
         Username:Sequelize.STRING,
         Password:Sequelize.STRING
     },{
         timestamps:false,
         freezeTableName:true
 });

//  LoginRegisterTable.sync({force:true}).then(()=>{
//     console.log("Table created successfully")
// }).catch (err => {
//     console.error("Error"+err);
// });
 
 const LoginRegisterData=
 {
    login:function(req,res){
        var Username=req.body.Username;
        var Password=req.body.Password;
        console.log(Username,Password);
        const Op=Sequelize.Op;
        LoginRegisterTable.findAll({raw:true}).then((data)=>{
           var flag=0;
            for(var i=0;i<data.length;i++){
               
                if(data[i].Username==Username || data[i].Password==Password )
                  {
                      if(data[i].Username==Username && data[i].Password==Password){
                        flag=1;
                        break;
                      }
                      else if(data[i].Username==Username && data[i].Password!=Password){
                          flag=2;
                      }
                  }
            }
           
            if(flag==1){
                console.log("User Password is Incorrect");
                res.status(201).send("User Name Correct .Please check your Password");
            }
            else{
               console.log("User Login UnSuccessful");
               res.status(201).send("User Login UnSuccessful");  
            }
           }).catch((err)=>{
               console.log("Error Encountered");
               res.status(400).send("Error Occured");
           })
    },
    register:function(req,res){
        var Username=req.body.Username;
        var Password=req.body.Password;
        
         var UserObj=LoginRegisterTable.build({Username:Username,Password:Password})
         UserObj.save().then(()=>{
             console.log("User Register Successfully");
            //  sendMail:function(req,res)
            //  {
             
            //  }
             res.status(201).send("User Registered Successfully");
         }).catch((err)=>{
             console.log(err);
             res.status(400).send("User Not Registered Successfully");
         })
    },
}
 
 module.exports=LoginRegisterData;
 


