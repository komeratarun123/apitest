const Sequelize=require("sequelize");
const db1= require("../db.config");
var sequelize = new Sequelize(db1.DB,db1.USER,db1.PASSWORD,{
    host:db1.HOST,
    dialect:db1.dialect,
    pool:{
        min:db1.pool.min,
        max:db1.pool.max,
        acquire:db1.pool.acquire,
        idle:db1.pool.idle
    }
});

let StaffTable=sequelize.define('StaffTable',{
    id:{
       primaryKey:true,
       type:Sequelize.STRING
     },
   username:Sequelize.STRING,
   Fullname:Sequelize.STRING
},{
   timestamps:false,
   freezeTableName:true
});


// StaffTable.sync({force:true}).then(()=>{
//     console.log("Table created successfully")
// }).catch (err => {
//     console.error("Error"+err);
// });

const StaffData=
{
    staff: function(req,res){
        console.log(req.body);
   var id =  req.body.id;
   var username =  req.body.username;
    var Fullname =  req.body.Fullname;
   var UserObj=StaffTable.build({id:id,
       username:username,Fullname:Fullname});
   UserObj.save().then(()=>{
       console.log("Query Successfully Send");
       res.send("Query Successfully Send");
   }).catch((err)=>{
       console.log("Error Encountered"+err);
       res.send("Error Encountered");
     })  
   }

}

module.exports=StaffData;