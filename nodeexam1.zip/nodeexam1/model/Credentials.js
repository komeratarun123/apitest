const Sequelize=require("sequelize");
const db1= require("../db.config");
var sequelize = new Sequelize(db1.DB,db1.USER,db1.PASSWORD,{
    host:db1.HOST,
    dialect:db1.dialect,
    pool:{
        min:db1.pool.min,
        max:db1.pool.max,
        acquire:db1.pool.acquire,
        idle:db1.pool.idle
    }
});

let CredentialsTable=sequelize.define('CredentialsTable',{
    id:{
       primaryKey:true,
       type:Sequelize.STRING
     },
   password:Sequelize.STRING,
   
},{
   timestamps:false,
   freezeTableName:true
});

// CredentialsTable.sync({force:true}).then(()=>{
//     console.log("Table created successfully")
// }).catch (err => {
//     console.error("Error"+err);
// });

const CredentialsData=
{
    credentials: function(req,res){
        console.log(req.body);
   var id =  req.body.id;
   var password =  req.body.password;
   
   var UserObj=CredentialsTable.build({id:id,
       password:password});
   UserObj.save().then(()=>{
       console.log("Query Successfully Send");
       res.send("Query Successfully Send");
   }).catch((err)=>{
       console.log("Error Encountered"+err);
       res.send("Error Encountered");
     })  
   }
}

module.exports=CredentialsData;