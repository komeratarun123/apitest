var express =require("express");
var PatientController=require("../controllers/PatientController");
var router=express.Router();
router.use(express.json());
router.get("/",PatientController.patientroot);
router.post('/patient',PatientController.patient);
module.exports=router;
