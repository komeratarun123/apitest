var express =require("express");
var StaffController=require("../controllers/StaffController");
var router=express.Router();
router.use(express.json());
router.get("/",StaffController.staffroot);
router.post('/staff',StaffController.staff);
module.exports=router;
