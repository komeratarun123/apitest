var express =require("express");
var LoginRegisterController=require("../controllers/LoginRegisterController");
var router=express.Router();
router.use(express.json());

router.get("/",LoginRegisterController.loginregister);
router.post('/register',LoginRegisterController.register);
router.post('/login',LoginRegisterController.login);

module.exports=router;