var express =require("express");
var CredentialsController=require("../controllers/CredentialsController");
var router=express.Router();
router.use(express.json());
router.get("/",CredentialsController.credentialsroot);
router.post('/credentials',CredentialsController.credentials);
module.exports=router;
