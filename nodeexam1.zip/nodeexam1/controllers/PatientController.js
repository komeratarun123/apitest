var PatientModel =require("../model/Patient");
const PatientController={
    patientroot:function(req,res){
        var strMsg="Server Running";
        console.log(strMsg);
        res.status(200).send(strMsg);
    },
    patient:function(req,res){
        return PatientModel.patient(req,res);
    }
}
module.exports=PatientController;