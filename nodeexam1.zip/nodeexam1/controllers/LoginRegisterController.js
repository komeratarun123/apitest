var LoginRegisterModel =require("../model/LoginRegister");
const LoginRegisterController={
    loginregister:function(req,res){
        var strMsg="Server Running of login";
        console.log(strMsg);
        res.send(200).send(strMsg);
    },
    login:function(req,res){
        return LoginRegisterModel.login(req,res);
         
    },
    register:function(req,res){
        return LoginRegisterModel.register(req,res);
    },
}
module.exports=LoginRegisterController;
