var CredentialsModel =require("../model/Credentials");
const CredentialsController={
    credentialsroot:function(req,res){
        var strMsg="Server Running";
        console.log(strMsg);
        res.status(200).send(strMsg);
    },
    credentials:function(req,res){
        return CredentialsModel.credentials(req,res);
    }
}
module.exports=CredentialsController;