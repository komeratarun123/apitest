var StaffModel =require("../model/Staff");
const StaffController={
    staffroot:function(req,res){
        var strMsg="Server Running";
        console.log(strMsg);
        res.status(200).send(strMsg);
    },
    staff:function(req,res){
        return StaffModel.staff(req,res);
    }
}
module.exports=StaffController;