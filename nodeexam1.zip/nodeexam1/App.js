const express =require("express");

var LoginRegister=require('./routes/LoginRegisterRoute');
var staff=require('./routes/StaffRoute');
var patient=require('./routes/PatientRoute')

var credentials = require('./routes/CredentialsRoute');

var app=express();


app.use("/LoginRegister",LoginRegister);
app.use("/StaffUser",staff);
app.use("/PatientUser",patient);
app.use("/CredentialsUser",credentials);


app.listen(8001,function(){
   console.log("Server is listening");
})